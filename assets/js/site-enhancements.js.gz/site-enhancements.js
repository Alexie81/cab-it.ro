(function () {
  "use strict";

  var localSiteRoot = window.location.pathname.indexOf("/cab-it.ro/") === 0 ? "/cab-it.ro" : "";

  function siteUrl(path) {
    return localSiteRoot + path;
  }

  var sharedXIcon = '<svg aria-hidden="true" focusable="false" viewBox="0 0 24 24"><path fill="currentColor" d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24h-6.657l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231 5.45-6.231Zm-1.161 17.52h1.833L7.084 4.126H5.117L17.083 19.77Z"/></svg>';
  var sharedYoutubeIcon = '<svg aria-hidden="true" focusable="false" viewBox="0 0 24 24"><rect x="2" y="5" width="20" height="14" rx="4" fill="currentColor"/><path d="m10 9 6 3-6 3Z" fill="#101010"/></svg>';
  var sharedInstagramIcon = '<svg aria-hidden="true" focusable="false" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="17.5" cy="6.5" r="1.2" fill="currentColor"/></svg>';

  if (localSiteRoot) {
    document.querySelectorAll('a[href^="/"]').forEach(function (link) {
      var href = link.getAttribute("href");
      if (href && href.indexOf("//") !== 0 && href.indexOf(localSiteRoot + "/") !== 0) {
        link.setAttribute("href", siteUrl(href));
      }
    });
    document.querySelectorAll('a[href^="https://cab-it.ro"]').forEach(function (link) {
      try {
        var url = new URL(link.getAttribute("href"));
        link.setAttribute("href", localSiteRoot + (url.pathname || "/") + url.search + url.hash);
      } catch (error) {
        // Keep the original URL if it cannot be parsed.
      }
    });
  }

  var isModernHomepage = document.body.classList.contains("cabit-homepage-modern");
  if (!isModernHomepage) {
    document.body.classList.add("cabit-modern-page");
  }
  var simpleHeader = document.querySelector(".cabit-simple-header");
  if (simpleHeader) {
    simpleHeader.outerHTML =
      '<header id="header-sticky" class="tp-header-transparent home-1-sticky header__sticky cabit-shared-legacy-header" data-cabit-shared-header>' +
        '<div class="tp-header-area tp-header-space tp-header-bottom-border p-relative z-index-1"><div class="container-fluid"><div class="row align-items-center">' +
          '<div class="col-6 col-xl-2"><div class="tp-header-logo tp-header-logo-border">' +
            '<a href="' + siteUrl("/") + '"><img src="' + siteUrl("/img/logo_home.png") + '" alt="Cab-IT Expert promovare online și creare site web" width="560" height="195"></a>' +
          '</div></div>' +
          '<div class="col-xl-6 d-none d-xl-block"><div class="tp-main-menu-area d-flex align-items-center pl-20">' +
            '<div class="tp-header-navbar tp-toogle d-none d-xxl-block"><button type="button" aria-label="Deschide navigarea"><span></span><span></span><span></span></button></div>' +
            '<div class="tp-main-menu d-none d-xl-block"><nav aria-label="Navigare principală"><ul>' +
              '<li><a href="' + siteUrl("/") + '">Acasa</a></li>' +
              '<li class="has-dropdown"><a href="' + siteUrl("/servicii/") + '">Meniu</a><ul class="submenu">' +
                '<li><a href="' + siteUrl("/despre-noi/") + '">Despre Noi</a></li>' +
                '<li><a href="' + siteUrl("/servicii/") + '">Servicii</a></li>' +
                '<li><a href="' + siteUrl("/preturi/") + '">Preturi</a></li>' +
                '<li><a href="' + siteUrl("/portofoliu/") + '">Portofoliu</a></li>' +
                '<li><a href="' + siteUrl("/blog/") + '">Blog</a></li>' +
                '<li><a href="' + siteUrl("/glosar-seo/") + '">Ghid SEO</a></li>' +
              '</ul></li>' +
              '<li><a href="' + siteUrl("/contact/") + '">Contact</a></li>' +
            '</ul></nav></div>' +
          '</div></div>' +
          '<div class="d-none d-lg-block col-lg-6 col-xl-4"><div class="tp-header-right d-flex align-items-center justify-content-end">' +
            '<div class="tp-header-btn d-flex ml-20"><a class="tp-btn-sm" href="' + siteUrl("/contact/") + '">Contact</a></div>' +
            '<div class="tp-header-btn d-flex ml-20"><a class="tp-btn-sm" href="tel:+40771532949"><span aria-hidden="true">☎</span> Apeleaza</a></div>' +
          '</div></div>' +
          '<div class="mobile-menu d-xl-none"><button type="button" class="tp-side-action tp-toogle hamburger-btn" aria-label="Deschide meniul" aria-expanded="false"><span></span><span></span><span></span></button></div>' +
        '</div></div></div>' +
      '</header>' +
      '<div class="tp-offcanvas-area fix cabit-shared-offcanvas" data-cabit-shared-offcanvas>' +
        '<div class="tp-side-info"><div class="tp-side-logo"><a href="' + siteUrl("/") + '"><img src="' + siteUrl("/img/logo_home.png") + '" alt="Cab-IT Expert" width="560" height="195"></a></div>' +
        '<div class="tp-side-close"><button type="button" aria-label="Închide meniul">×</button></div>' +
        '<div class="tp-side-content p-relative"><h3 class="tp-side-title">Ajutăm la crearea strategiilor vizuale.</h3><p>Vrem să auzim de la tine. Spune-ne cum vă putem ajuta.</p><div class="tp-side-content-inner-content">' +
          '<div class="tp-side-thumb text-center"><img src="' + siteUrl("/assets/img/hero/mobile-menu.png") + '" alt="Echipa Cab-IT Expert"></div>' +
          '<div class="tp-side-btn text-xl-center mb-80"><a class="tp-btn" href="' + siteUrl("/contact/") + '">Hai să ne cunoaștem!</a></div>' +
          '<nav class="cabit-shared-mobile-nav" aria-label="Navigare mobilă"><a href="' + siteUrl("/") + '">Acasa</a><a href="' + siteUrl("/despre-noi/") + '">Despre Noi</a><a href="' + siteUrl("/servicii/") + '">Servicii</a><a href="' + siteUrl("/preturi/") + '">Preturi</a><a href="' + siteUrl("/portofoliu/") + '">Portofoliu</a><a href="' + siteUrl("/blog/") + '">Blog</a><a href="' + siteUrl("/glosar-seo/") + '">Ghid SEO</a><a href="' + siteUrl("/contact/") + '">Contact</a></nav>' +
          '<div class="tp-side-contact mb-40"><p class="call"><a href="tel:+40771532949">+40 771 532 949</a></p><p class="mail"><a href="mailto:contact@cab-it.ro">contact@cab-it.ro</a></p></div>' +
          '<div class="tp-footer-social-1"><a href="https://www.youtube.com/@cabitexpert" aria-label="YouTube">' + sharedYoutubeIcon + '</a><a href="https://www.facebook.com/profile.php?id=61592087996523" aria-label="Facebook"><strong>f</strong></a><a href="https://www.instagram.com/cabitexpert/" aria-label="Instagram">' + sharedInstagramIcon + '</a><a href="https://www.linkedin.com/company/cab-it-expert/" aria-label="LinkedIn"><strong>in</strong></a><a href="https://x.com/cabitexpert" aria-label="X">' + sharedXIcon + '</a></div>' +
        '</div></div></div>' +
        '<button type="button" class="offcanvas-overlay" aria-label="Închide meniul"></button>' +
      '</div>';
  }

  var servicePage = document.body.classList.contains("cabit-service-page");
  if (servicePage) {
    var serviceIcons = {
      analysis: '<path d="M5 24V8m0 16h22M9 20l5-6 5 3 8-10"/><path d="M22 7h5v5"/>',
      website: '<rect x="4" y="6" width="24" height="20" rx="3"/><path d="M4 12h24M9 9h.01M13 9h.01M10 18h12M10 22h7"/>',
      automation: '<circle cx="7" cy="16" r="3"/><circle cx="25" cy="8" r="3"/><circle cx="25" cy="24" r="3"/><path d="M10 16h5a4 4 0 0 0 4-4v0a4 4 0 0 1 3-4M10 16h5a4 4 0 0 1 4 4v0a4 4 0 0 0 3 4"/>',
      conversion: '<circle cx="16" cy="16" r="11"/><circle cx="16" cy="16" r="5"/><path d="m19 13 8-8M22 5h5v5"/>',
      ads: '<path d="M6 18h4l11 5V8l-11 5H6a3 3 0 0 0 0 5Z"/><path d="m10 18 2 7h4l-2-6M25 12l3-2M25 17l3 2"/>',
      seo: '<circle cx="14" cy="14" r="8"/><path d="m20 20 7 7M10 15l3 3 5-7"/>',
      local: '<path d="M25 13c0 7-9 15-9 15S7 20 7 13a9 9 0 1 1 18 0Z"/><circle cx="16" cy="13" r="3"/>',
      social: '<path d="M7 7h13a5 5 0 0 1 5 5v4a5 5 0 0 1-5 5h-7l-6 5v-5a5 5 0 0 1-5-5v-4a5 5 0 0 1 5-5Z"/><path d="M9 14h.01M14 14h.01M19 14h.01"/>'
    };
    var serviceKey = document.body.getAttribute("data-service") || "analysis";
    var serviceHero = document.querySelector(".cabit-page-header .container");
    if (serviceHero) {
      var serviceIcon = document.createElement("span");
      serviceIcon.className = "cabit-service-hero-icon";
      serviceIcon.setAttribute("aria-hidden", "true");
      serviceIcon.innerHTML = '<svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + (serviceIcons[serviceKey] || serviceIcons.analysis) + '</svg>';
      serviceHero.insertBefore(serviceIcon, serviceHero.firstChild);

      var serviceActions = document.createElement("div");
      serviceActions.className = "cabit-service-hero-actions";
      serviceActions.innerHTML = '<a class="cabit-service-primary" href="' + siteUrl("/contact/") + '">Solicită o discuție</a><a class="cabit-service-secondary" href="' + siteUrl("/portofoliu/") + '">Vezi proiectele</a>';
      serviceHero.appendChild(serviceActions);
    }
  }

  var simpleFooter = document.querySelector(".cabit-site-footer");
  if (simpleFooter) {
    var xIcon = sharedXIcon;
    var youtubeIcon = sharedYoutubeIcon;
    var instagramIcon = sharedInstagramIcon;
    simpleFooter.outerHTML =
      '<footer class="p-relative include-bg cabit-shared-legacy-footer" style="background-image:url(' + siteUrl("/img/footer-bg-3.jpg") + ')">' +
        '<div class="tp-footer-area-3 pt-115"><div class="tp-footer-top-widget-3 p-relative"><div class="container container-large"><div class="row">' +
          '<div class="col-xl-3 col-lg-3 col-sm-6 col-12"><div class="tp-footer-widget-3 tp-space-col-1 mb-40"><div class="tp-footer-logo"><a href="' + siteUrl("/") + '"><img src="' + siteUrl("/img/logo_home.png") + '" alt="Cab-IT Expert" width="560" height="195"></a></div><p>Servicii de dezvoltare web și promovare online construite în jurul obiectivelor și datelor fiecărui client.</p><div class="tp-footer-social-3">' +
            '<a href="https://www.youtube.com/@cabitexpert" aria-label="Cab-IT Expert pe YouTube">' + youtubeIcon + '</a><a href="https://www.facebook.com/profile.php?id=61592087996523" aria-label="Cab-IT Expert pe Facebook"><strong>f</strong></a><a href="https://www.instagram.com/cabitexpert/" aria-label="Cab-IT Expert pe Instagram">' + instagramIcon + '</a><a href="https://www.linkedin.com/company/cab-it-expert/" aria-label="Cab-IT Expert pe LinkedIn"><strong>in</strong></a><a href="https://x.com/cabitexpert" aria-label="Cab-IT Expert pe X">' + xIcon + '</a>' +
          '</div></div></div>' +
          '<div class="col-xl-3 col-lg-2 col-sm-6 col-12"><div class="tp-footer-widget-3 tp-space-col-2 mb-40"><span class="tp-footer-widget__title">Quick Links</span><ul><li><a href="' + siteUrl("/") + '">Acasa</a></li><li><a href="' + siteUrl("/despre-noi/") + '">Despre Noi</a></li><li><a href="' + siteUrl("/servicii/") + '">Servicii</a></li><li><a href="' + siteUrl("/portofoliu/") + '">Portofoliu</a></li><li><a href="' + siteUrl("/blog/") + '">Blog</a></li><li><a href="' + siteUrl("/glosar-seo/") + '">Ghid SEO</a></li><li><a href="' + siteUrl("/contact/") + '">Contact</a></li></ul></div></div>' +
          '<div class="col-xl-2 col-lg-3 col-sm-6 col-12"><div class="tp-footer-widget-3 tp-space-col-3 footer-info mb-40"><span class="tp-footer-widget__title">Contact info</span><ul><li><a href="https://www.google.com/maps/search/?api=1&amp;query=Intrarea+Humule%C8%99ti+6A+052034+Bucure%C8%99ti+Rom%C3%A2nia">Intrarea Humulești 6A, 052034 București, România</a></li><li>Program non-stop</li><li><a href="mailto:contact@cab-it.ro">contact@cab-it.ro</a></li><li><a href="mailto:office@cab-it.ro">HR: office@cab-it.ro</a></li><li><a href="tel:+40771532949">+40 771 532 949</a></li></ul></div></div>' +
          '<div class="col-xl-4 col-lg-4 col-sm-6 col-12"><div class="tp-footer-widget-3 tp-space-col-4 mb-30"><span class="tp-footer-widget__title">Subscribe Newsletter</span><p>Primește ghiduri practice despre SEO, promovare online și website-uri.</p><div class="tp-footer-subscribe-input-3"><form class="p-relative" action="' + siteUrl("/newsletter-subscribe.php") + '" method="post"><label class="visually-hidden" for="cabit-shared-footer-email">Adresa de email</label><input id="cabit-shared-footer-email" type="email" name="email" placeholder="Adresa ta de email" autocomplete="email" required><input type="hidden" name="source" value="footer-pagini-noi"><input class="cabit-honeypot" type="text" name="website" tabindex="-1" autocomplete="off" aria-hidden="true"><button class="tp-footer-btn" type="submit" aria-label="Abonează-te">→</button></form></div></div></div>' +
        '</div></div></div><div class="tp-footer-bottom-widget"><div class="container container-large"><div class="tp-footer-copyright-2"><div class="row"><div class="col-md-12 col-lg-6"><div class="tp-footer-copyright-inner-2 pb-20"><p>©Copyright <span data-current-year>2026</span> All Rights Reserved</p></div></div><div class="col-md-12 col-lg-6"><div class="tp-footer-copyright-link-2 text-lg-end pb-20"><a href="' + siteUrl("/termeni-si-conditii/") + '">Terms and conditions</a></div></div></div></div></div></div></div>' +
      '</footer>';
  }

  var sharedLegacyHeader = document.querySelector("[data-cabit-shared-header]");
  var sharedOffcanvas = document.querySelector("[data-cabit-shared-offcanvas]");
  if (sharedLegacyHeader && sharedOffcanvas) {
    var sideInfo = sharedOffcanvas.querySelector(".tp-side-info");
    var sideOverlay = sharedOffcanvas.querySelector(".offcanvas-overlay");
    var menuButtons = sharedLegacyHeader.querySelectorAll(".tp-toogle");
    var closeButton = sharedOffcanvas.querySelector(".tp-side-close button");

    var setMobileMenu = function (open) {
      sideInfo.classList.toggle("tp-side-info-open", open);
      sideOverlay.classList.toggle("offcanvas-overlay-open", open);
      document.body.classList.toggle("cabit-menu-open", open);
      menuButtons.forEach(function (button) { button.setAttribute("aria-expanded", open ? "true" : "false"); });
    };

    menuButtons.forEach(function (button) {
      button.addEventListener("click", function () { setMobileMenu(true); });
    });
    closeButton.addEventListener("click", function () { setMobileMenu(false); });
    sideOverlay.addEventListener("click", function () { setMobileMenu(false); });
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") { setMobileMenu(false); }
    });

    var updateLegacyHeader = function () {
      sharedLegacyHeader.classList.toggle("header-sticky", window.scrollY > 70);
    };
    updateLegacyHeader();
    window.addEventListener("scroll", updateLegacyHeader, { passive: true });
  }

  var newsletterStatus = new URLSearchParams(window.location.search).get("newsletter");
  if (newsletterStatus) {
    var newsletterMessages = {
      success: "Mulțumim! Adresa ta a fost adăugată la newsletter.",
      exists: "Această adresă este deja abonată la newsletter.",
      invalid: "Adresa de email nu este validă. Te rugăm să încerci din nou."
    };
    var notice = document.createElement("div");
    notice.className = "cabit-newsletter-notice" + (newsletterStatus === "invalid" ? " is-error" : "");
    notice.setAttribute("role", "status");
    notice.textContent = newsletterMessages[newsletterStatus] || newsletterMessages.invalid;
    document.body.appendChild(notice);
    window.setTimeout(function () { notice.remove(); }, 7000);
  }

  if (!document.getElementById("cabit-google-fonts")) {
    var fonts = document.createElement("link");
    fonts.id = "cabit-google-fonts";
    fonts.rel = "stylesheet";
    fonts.href = "https://fonts.googleapis.com/css2?family=Montserrat+Alternates:wght@400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=optional";
    document.head.appendChild(fonts);
  }

  var articleCarousel = document.querySelector("[data-articles-carousel]");
  if (articleCarousel) {
    var articleCards = Array.prototype.slice.call(articleCarousel.querySelectorAll(".cabit-blog-card"));
    var carouselShell = articleCarousel.closest(".cabit-articles-carousel");
    var previousArticle = carouselShell ? carouselShell.querySelector("[data-carousel-previous]") : null;
    var nextArticle = carouselShell ? carouselShell.querySelector("[data-carousel-next]") : null;
    var carouselStatus = carouselShell ? carouselShell.querySelector("[data-carousel-status]") : null;

    function carouselStep() {
      if (!articleCards.length) {
        return articleCarousel.clientWidth;
      }
      var carouselStyles = window.getComputedStyle(articleCarousel);
      return articleCards[0].getBoundingClientRect().width + (parseFloat(carouselStyles.columnGap || carouselStyles.gap) || 0);
    }

    function updateArticleCarousel() {
      var maxScroll = Math.max(0, articleCarousel.scrollWidth - articleCarousel.clientWidth - 2);
      if (previousArticle) {
        previousArticle.disabled = articleCarousel.scrollLeft <= 2;
      }
      if (nextArticle) {
        nextArticle.disabled = articleCarousel.scrollLeft >= maxScroll;
      }
      if (carouselStatus) {
        var current = articleCards.length ? Math.min(articleCards.length, Math.round(articleCarousel.scrollLeft / Math.max(carouselStep(), 1)) + 1) : 0;
        carouselStatus.textContent = articleCards.length ? current + " / " + articleCards.length : "Nu există articole";
      }
    }

    if (previousArticle) {
      previousArticle.addEventListener("click", function () {
        articleCarousel.scrollBy({ left: -carouselStep(), behavior: "smooth" });
      });
    }
    if (nextArticle) {
      nextArticle.addEventListener("click", function () {
        articleCarousel.scrollBy({ left: carouselStep(), behavior: "smooth" });
      });
    }
    articleCarousel.addEventListener("scroll", updateArticleCarousel, { passive: true });
    window.addEventListener("resize", updateArticleCarousel);
    updateArticleCarousel();
  }

  var motionItems = document.querySelectorAll(
    ".cabit-homepage-modern .cabit-solution-card, .cabit-homepage-modern .cabit-home-faq details, .cabit-homepage-modern .cabit-home-services .col-custom, .cabit-service-page .cabit-content-card, .cabit-service-page .cabit-note"
  );
  if (motionItems.length) {
    var prefersReducedMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    document.body.classList.add("cabit-motion-ready");
    motionItems.forEach(function (item, index) {
      item.style.setProperty("--cabit-reveal-delay", Math.min(index % 5, 4) * 70 + "ms");
    });
    if (prefersReducedMotion || !("IntersectionObserver" in window)) {
      motionItems.forEach(function (item) { item.classList.add("is-visible"); });
    } else {
      var motionObserver = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            motionObserver.unobserve(entry.target);
          }
        });
      }, { rootMargin: "0px 0px -7%", threshold: 0.08 });
      motionItems.forEach(function (item) { motionObserver.observe(item); });
    }
  }

  document.querySelectorAll("[data-current-year]").forEach(function (element) {
    element.textContent = new Date().getFullYear();
  });

  var counters = document.querySelectorAll("[data-count-target]");
  if (!counters.length) {
    return;
  }

  var reducedMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function setFinalValue(element) {
    element.textContent = element.dataset.countTarget;
  }

  function animateCounter(element) {
    if (element.dataset.counted === "true") {
      return;
    }

    element.dataset.counted = "true";
    var target = Number(element.dataset.countTarget);
    var duration = Number(element.dataset.countDuration || 900);

    if (!Number.isFinite(target) || reducedMotion) {
      setFinalValue(element);
      return;
    }

    var startTime;
    element.textContent = "0";

    function frame(timestamp) {
      if (!startTime) {
        startTime = timestamp;
      }

      var progress = Math.min((timestamp - startTime) / duration, 1);
      var easedProgress = 1 - Math.pow(1 - progress, 3);
      element.textContent = Math.round(target * easedProgress).toLocaleString("ro-RO");

      if (progress < 1) {
        window.requestAnimationFrame(frame);
      } else {
        setFinalValue(element);
      }
    }

    window.requestAnimationFrame(frame);
  }

  if (!("IntersectionObserver" in window)) {
    counters.forEach(setFinalValue);
    return;
  }

  var observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
        observer.unobserve(entry.target);
      }
    });
  }, { rootMargin: "0px 0px -5%", threshold: 0.2 });

  counters.forEach(function (counter) {
    setFinalValue(counter);
    observer.observe(counter);
  });
}());
